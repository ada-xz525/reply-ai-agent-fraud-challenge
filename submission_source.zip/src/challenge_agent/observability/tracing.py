import os
from typing import Any


class _NoOpLangfuse:
    def flush(self) -> None:
        return None


class _NoOpCallbackHandler:
    pass


def _noop_observe(*_args: Any, **_kwargs: Any):
    def decorator(func):
        return func

    return decorator


try:
    from langfuse import Langfuse, observe
    from langfuse.langchain import CallbackHandler
except ImportError:
    Langfuse = None
    CallbackHandler = _NoOpCallbackHandler
    observe = _noop_observe


if Langfuse is not None and os.getenv("LANGFUSE_PUBLIC_KEY") and os.getenv("LANGFUSE_SECRET_KEY"):
    langfuse_client = Langfuse(
        public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
        secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
        host=os.getenv("LANGFUSE_HOST", "https://challenges.reply.com/langfuse"),
    )
else:
    langfuse_client = _NoOpLangfuse()


def build_callback_handler():
    try:
        return CallbackHandler()
    except Exception:
        return _NoOpCallbackHandler()


__all__ = ["langfuse_client", "build_callback_handler", "observe"]
